package card.cards;

import player.Player;

//You CAN modify the first line
public class ExodiaPartCard{
	
	
	public ExodiaPartCard(String name, int defense) {
		String description = "Assemble 4 of Exodia part card to win the game";
		int lpBonus = 0;
		int attackBonus = 0;

	}
	


}