package card.cards;

import card.base.CharacterCard;
import card.base.ItemCard;
import player.Player;

//You CAN modify the first line
public class ExodiaCharacterCard{
		
	public ExodiaCharacterCard() {
		String name = "Exodia the Forbidden One";
		String description = "With 4 or more Exodia Part Card equiped, you win the game";
		int lifePoint = 800;
		int attackPoint = 0;
		int defensePoint = 25;

	}
	
	//Fill Code Here
	
	public boolean winConditionCheck(ItemCard[] inventory) {

	}
}