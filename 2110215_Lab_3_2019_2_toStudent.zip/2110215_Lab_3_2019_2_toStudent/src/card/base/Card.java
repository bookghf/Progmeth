package card.base;


//You CAN modify the first line
public class Card {	
	public Card(String name, String description) {	}
	
	
	
	public String getName() {
	}
	
	public String getDescription() {
	}
}
