package deck;

//you CAN modify the first line
public class InsertCardFailedException  {
	// you CAN add SerialVersionID if eclipse gives you warning
}
