package deck;

public class RemoveCardFailedException extends Exception {
	// you CAN add SerialVersionID if eclipse gives you warning
}
